create function setprog() returns integer
LANGUAGE plpgsql
AS $$
DECLARE

names text[] := 
'{ 
Action Script,
Ada,
AspectJ,
AspectLua,
Basic,
C#,
C++,
C++/CLI,
CaesarJ,
Cat,
Cg,
Clean,
ColdFusion,
Component Pascal,
Compose*,
Curry,
D,
Delphi,
Dylan,
Eiffel,
Erlang,
Euphoria,
F#,
Game Maker Language(GML),
Gentee,
GNU bc,
Groovy,
Haskell,
haXe,
Hope,
Io,
J,
Java,
JavaScript,
JOVIAL,
Limbo,
Lua,
Maple,
Mathematica,
MATLAB,
MC#,
Mercury,
Mozart,
Nemerle,
Object Pascal,
Objective-C,
ObjectTeams,
OCaml,
Occam,
Pascal,
Perl,
PHP,
Pike,
PL/M,
Prolog,
PureBasic ,
Python,
QBASIC,
REXX,
Ruby,
Scala,
Scheme,
Scilab,
Self,
sh,
Simula,
Smalltalk,
Swift,
Vala,
Visual Basic,
Visual DataFlex,
Zonnon,
Активный Оберон,
Алгол,
Алгол 68,
АПЛ,
Би,
КОБОЛ,
Компонентный Паскаль,
Лисп,
Лого,
Модула,
Модула-2,
Модула-3,
Оберон,
Оберон-2,
Паскаль,
ПЛ/1,
Рапира,
РЕФАЛ,
Си,
Упрощённый Алгол,
Фокал,
Фортран
}'; 

i INTEGER;

BEGIN

i := 1; 

while names[i] is not null loop

INSERT INTO ЭЛЕМЕНТ(НАЗВАНИЕ, ИД_ВИДА, СОСТОЯНИЕ)
VALUES(names[i], 5, TRUE);

i := i+1; 

end loop;

RETURN 1; 

end;
$$;
