create function someautors() returns integer
LANGUAGE plpgsql
AS $$
DECLARE
names text[] := '{ 
Юкихиро,
Андерс,
Томас,
Джон,
Гвидо,
Валентин,
Бертран,
Брендан,
Бьёрн
}'; 

surnames text[] := '{ 
Мацумото,
Хейлсберг,
Курц,
Кемени,
ван Россум,
Турчин,
Мейер,
Эйх,
Страуструп
}';

countries text[] := '{
Япония,
Дания,
США,
США,
Нидерланды,
Россия,
Франция,
США,
Дания
}';

nations text[] := '{
японцы,
датчане,
амерканцы,
американцы,
нидерландцы,
русские,
французы,
американцы,
датчане
}';

i INTEGER;


begin


i := 1; 
while names[i] is not null loop
INSERT INTO АВТОРЫ (ИМЯ, ФАМИЛИЯ, ИД_НАЦИОНАЛЬНОСТИ)
VALUES(names[i], surnames[i], (select ИД_НАЦИОНАЛЬНОСТИ FROM НАЦИОНАЛЬНОСТЬ_И_МЕСТОПОЛОЖЕНИЕ WHERE СТРАНА = countries[i] AND НАЦИОНАЛЬНОСТЬ = nations[i]));

i := i+1; 
end loop;
RETURN 1; 
end;
$$;
