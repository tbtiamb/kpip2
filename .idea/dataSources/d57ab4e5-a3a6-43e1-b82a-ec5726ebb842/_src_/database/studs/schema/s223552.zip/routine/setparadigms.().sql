create function setparadigms() returns integer
LANGUAGE plpgsql
AS $$
DECLARE

names text[] := 
'{ 
Аспектно-ориентированные, 
Структурные, 
Процедурные, 
Логические, 
Объектно-ориентированные, 
Функциональные, 
Мультипарадигмальные 
}'; 

i INTEGER;

BEGIN

i := 1; 

while names[i] is not null loop

INSERT INTO ПАРАДИГМЫ(ПАРАДИГМА)

VALUES(names[i]);

i := i+1; 

end loop;

RETURN 1; 

end;
$$;
