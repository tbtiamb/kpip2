create function setras() returns integer
LANGUAGE plpgsql
AS $$
DECLARE

names text[] := 
'{ 
.aj, 
.bas, 
.pas, 
.inc, 
.Mod, 
.for, 
.f90, 
.f95, 
.e, 
.ex, 
.exw, 
.edb, 
.pb, 
.pbi, 
.pbp, 
.pbf, 
.mod, 
.cbl, 
.cob, 
.cpy, 
.c, 
.h, 
.m, 
.pl, 
.pro, 
.cpp, 
.cc, 
.cxx, 
.hpp, 
.hh, 
.hxx, 
.d, 
.dpr, 
.dpk, 
.pp, 
.gml, 
.gmk, 
.gm6, 
.gmd, 
.gm8, 
.gm81, 
.groovy, 
.io, 
.java, 
.js, 
.p, 
.mm, 
.pm, 
.cgi, 
.php, 
.phtml, 
.php4, 
.php3, 
.php5, 
.phps, 
.py, 
.pyw, 
.pyc, 
.pyo, 
.rb, 
.rbw, 
.swift, 
.vala, 
.vapi, 
.cls, 
.frm, 
.vbp, 
.vbg, 
.znn, 
.erl, 
.hs, 
.lhs, 
.ijs, 
.scm, 
.ss, 
.cs 
}'; 

i INTEGER;

BEGIN

i := 1; 

while names[i] is not null loop

INSERT INTO РАСШИРЕНИЯ(РАСШИРЕНИЕ)

VALUES(names[i]);

i := i+1; 

end loop;

RETURN 1; 

end;
$$;
