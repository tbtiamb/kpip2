create function connectsomeautors() returns integer
LANGUAGE plpgsql
AS $$
DECLARE
names text[] := '{ 
Андерс,
Бертран,
Брендан,
Бьёрн,
Валентин,
Гвидо,
Джон,
Томас,
Юкихиро,
Андерс
}'; 

surnames text[] := '{ 
Хейлсберг,
Мейер,
Эйх,
Страуструп,
Турчин,
ван Россум,
Кемени,
Курц,
Мацумото,
Хейлсберг
}'; 

langs text[] := '{
C#,
Активный Оберон,
JavaScript,
C++,
РЕФАЛ,
Python,
Basic,
Basic,
Ruby,
Delphi
}';

i INTEGER;


begin


i := 1; 
while langs[i] is not null loop
INSERT INTO АВТОР_ЯЗЫКА
VALUES((SELECT ИД_ЭЛЕМЕНТА FROM ЭЛЕМЕНТ WHERE НАЗВАНИЕ = langs[i]), (SELECT ИД_АВТОРА FROM АВТОРЫ WHERE ИМЯ = names[i] AND ФАМИЛИЯ = surnames[i]));

i := i+1; 
end loop;
RETURN 1; 
end;
$$;
